package com.autosprint;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoSprintMod implements ClientModInitializer {

    private boolean enabled = true;

    @Override
    public void onInitializeClient() {

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            ClientPlayerEntity player = client.player;

            if (!enabled) return;

            // PvP логика: спринт всегда при движении, даже в воздухе
            if (client.options.forwardKey.isPressed()) {

                if (!player.isSneaking()) {
                    player.setSprinting(true);
                }
            }
        });
    }
}
